package com.klef.jfsd.exam;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Arrays;
import java.util.List;

@Service
public class ProductService {
    private final RestTemplate restTemplate;

    public ProductService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<Object> fetchAllProducts() {
        String url = "https://fakestoreapi.com/products";
        Object[] products = restTemplate.getForObject(url, Object[].class);
        return Arrays.asList(products);
    }
}
